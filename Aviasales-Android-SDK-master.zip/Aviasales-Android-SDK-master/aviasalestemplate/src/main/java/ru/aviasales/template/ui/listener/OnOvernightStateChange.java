package ru.aviasales.template.ui.listener;

public interface OnOvernightStateChange {
	void onChange(boolean airportOvernight);
}
