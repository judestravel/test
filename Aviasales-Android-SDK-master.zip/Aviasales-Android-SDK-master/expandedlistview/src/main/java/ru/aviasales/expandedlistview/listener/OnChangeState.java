package ru.aviasales.expandedlistview.listener;

public interface OnChangeState {

	void onChange(Object object);
}
